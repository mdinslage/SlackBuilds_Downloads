#ifndef HIDKEYTONAME
#define HIDKEYTONAME

#include <QString>

QString HIDKeyToName(unsigned int key);

#endif // HIDKEYTONAME