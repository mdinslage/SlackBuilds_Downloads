#ifndef QTKEYTOHID_H
#define QTKEYTOHID_H

#include <Qt>

extern unsigned int QtKeyToHID(quint32 key);

#endif // QTKEYTOHID_H
