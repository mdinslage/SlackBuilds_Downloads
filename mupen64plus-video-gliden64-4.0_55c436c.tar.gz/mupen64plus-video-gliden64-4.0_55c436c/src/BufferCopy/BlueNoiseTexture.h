#pragma once

struct BlueNoiseItem
{
	signed char r, g, b;
};

extern const BlueNoiseItem blueNoiseTex[8][64][64];
