#ifndef S2DEX2_H
#define S2DEX2_H

void S2DEX2_Init();

#endif
