#ifndef F3DEX2_ACCLAIM_H
#define F3DEX2_ACCLAIM_H

void F3DEX2ACCLAIM_Init();

#endif

