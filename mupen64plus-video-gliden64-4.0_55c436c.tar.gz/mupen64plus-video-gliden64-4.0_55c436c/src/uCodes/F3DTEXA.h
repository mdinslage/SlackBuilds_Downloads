#ifndef F3DTEXA_H
#define F3DTEXA_H

void F3DTEXA_Init();

#endif
