#ifndef F3DFLX2_H
#define F3DFLX2_H

void F3DFLX2_Init();

#endif // F3DFLX2_H
