#ifndef L3DEX2_H
#define L3DEX2_H
#include "Types.h"

#define	L3DEX2_TRI1				0x05
#define L3DEX2_TRI2				0x06
#define L3DEX2_LINE3D			0x08

void L3DEX2_Init();
#endif

