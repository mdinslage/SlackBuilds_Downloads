#ifndef T3DUX_H
#define T3DUX_H

void RunT3DUX();

#endif // T3DUX_H
