#ifndef F3DSETA_H
#define F3DSETA_H

void F3DSETA_Init();

#endif

