#ifndef F5INDI_NABOO_H
#define F5INDI_NABOO_H

void F5Indi_Naboo_Init();

#endif
