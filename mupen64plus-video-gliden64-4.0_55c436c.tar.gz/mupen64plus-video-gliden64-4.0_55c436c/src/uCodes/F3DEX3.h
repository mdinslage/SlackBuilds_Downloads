#ifndef F3DEX3_H
#define F3DEX3_H

void F3DEX3_Init();

#endif // F3DEX3_H
