#pragma once
#include "Platform.h"
#include "Types.h"

bool isMemoryWritable(void * ptr, size_t byteCount);
