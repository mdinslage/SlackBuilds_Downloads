#ifndef SCREENSHOT_H
#define SCREENSHOT_H

void SaveScreenshot(const wchar_t * _folder, const char * _name, int _width, int _height, const unsigned char * _data);

#endif // SCREENSHOT_H
